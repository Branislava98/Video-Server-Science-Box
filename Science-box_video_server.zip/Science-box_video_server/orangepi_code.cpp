// Server code running on Orange Pi

#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <iostream>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>

#define PORT 8080

int main() {
    // Open two cameras
    cv::VideoCapture cap1(0); // Assuming the first camera is at index 0
    cv::VideoCapture cap2(1); // Assuming the second camera is at index 1
    cv::VideoCapture cap3(2); // Assuming the first camera is at index 2
    cv::VideoCapture cap4(3); // Assuming the second camera is at index 3
    cv::VideoCapture cap5(4); // Assuming the first camera is at index 5


    cap1.set(cv::CAP_PROP_FRAME_WIDTH, 640);
    cap1.set(cv::CAP_PROP_FRAME_HEIGHT, 480);

    cap2.set(cv::CAP_PROP_FRAME_WIDTH, 640);
    cap2.set(cv::CAP_PROP_FRAME_HEIGHT, 480);
  
    cap3.set(cv::CAP_PROP_FRAME_WIDTH, 640);
    cap3.set(cv::CAP_PROP_FRAME_HEIGHT, 480);
    
    cap4.set(cv::CAP_PROP_FRAME_WIDTH, 640);
    cap4.set(cv::CAP_PROP_FRAME_HEIGHT, 480);

    cap5.set(cv::CAP_PROP_FRAME_WIDTH, 640);
    cap5.set(cv::CAP_PROP_FRAME_HEIGHT, 480);
	

    if (!cap1.isOpened() || !cap2.isOpened() || !cap3.isOpened() || !cap4.isOpened() || !cap5.isOpened()) {
        std::cerr << "Error opening one of the cameras." << std::endl;
        return -1;
    }
    // Create socket
    int serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == -1) {
        std::cerr << "Error creating socket." << std::endl;
        return -1;
    }

    sockaddr_in serverAddress{};
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_addr.s_addr = INADDR_ANY;
    serverAddress.sin_port = htons(PORT);

    // Bind the socket
    if (bind(serverSocket, (struct sockaddr*)&serverAddress, sizeof(serverAddress)) == -1) {
        std::cerr << "Error binding socket." << std::endl;
        return -1;
    }

    // Listen for incoming connections
    if (listen(serverSocket, 1) == -1) {
        std::cerr << "Error listening for connections." << std::endl;
        return -1;
    }

    std::cout << "Server waiting for connections..." << std::endl;

    int clientSocket = accept(serverSocket, nullptr, nullptr);
    if (clientSocket == -1) {
        std::cerr << "Error accepting client connection." << std::endl;
        return -1;
    }

    std::cout << "Client connected." << std::endl;
	int count = 0;
    while (true) {
		count += 1;
		std::cerr << count << std::endl;
        cv::Mat frame1, frame2, frame3, frame4, frame5;
        cap1 >> frame1; // Capture a frame from the first camera
        cap2 >> frame2; // Capture a frame from the second camera
        cap3 >> frame3;
        cap4 >> frame4;
        cap5 >> frame5;

        // Send the frames to the client
        int frameSize1 = frame1.total() * frame1.elemSize();
        int frameSize2 = frame2.total() * frame2.elemSize();
        int frameSize3 = frame3.total() * frame3.elemSize();
        int frameSize4 = frame4.total() * frame4.elemSize();
	int frameSize5 = frame5.total() * frame5.elemSize();
        if (send(clientSocket, frame1.data, frameSize1, 0) == -1 || send(clientSocket, frame2.data, frameSize2, 0) == -1
        	|| send(clientSocket, frame3.data, frameSize3, 0) == -1 || send(clientSocket, frame4.data, frameSize4, 0) == -1
        	|| send(clientSocket, frame5.data, frameSize5, 0) == -1) {
            std::cerr << "Error sending frames." << std::endl;
            break;
        }

        char key = cv::waitKey(30);
        if (key == 27) // 'ESC' key to exit
            break;
        
    }

    // Release resources
    close(clientSocket);
    close(serverSocket);
    cap1.release();
    cap2.release();
    cap3.release();
    cap4.release();
    cap5.release();
    cv::destroyAllWindows();

    return 0;
} 
