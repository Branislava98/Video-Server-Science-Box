#include <QApplication>
#include <QMainWindow>
#include <QLabel>
#include <QTimer>
#include <QImage>
#include <QPushButton>
#include <QDebug>
#include <QPalette>
#include <QDateTime> 
#include <QLineEdit> 
#include <QDir> 
#include <QFileDialog> 
#include <QMessageBox> 
#include <QInputDialog>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <iostream>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>

#define PORT 8080
#define WIDTH 640
#define HEIGHT 480
#define BUFFER_SIZE (WIDTH * HEIGHT * 3)

cv::Mat frame1;
cv::Mat frame2;
cv::Mat frame3;
cv::Mat frame4;
cv::Mat frame5;

bool camera1On = false;
bool camera2On = false;
bool camera3On = false;
bool camera4On = false;
bool camera5On = false;

bool socketConnected = false;
int clientSocket = 0;

char buffer1[BUFFER_SIZE];
char buffer2[BUFFER_SIZE];
char buffer3[BUFFER_SIZE];
char buffer4[BUFFER_SIZE];
char buffer5[BUFFER_SIZE];

bool isRecording1 = false;
bool isRecording2 = false;
bool isRecording3 = false;
bool isRecording4 = false;
bool isRecording5 = false;

cv::VideoWriter writer1;
cv::VideoWriter writer2;
cv::VideoWriter writer3;
cv::VideoWriter writer4;
cv::VideoWriter writer5;

bool captureDurationActive1 = false;
bool captureDurationActive2 = false;
bool captureDurationActive3 = false;
bool captureDurationActive4 = false;
bool captureDurationActive5 = false;

char index1 = '1';
char index2 = '2';
char index3 = '3';
char index4 = '4';
char index5 = '5';


QTimer captureDurationTimer1;
QTimer captureDurationTimer2;
QTimer captureDurationTimer3;
QTimer captureDurationTimer4;
QTimer captureDurationTimer5;

void connectToServer() {
    // Create socket
    clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket == -1) {
        std::cerr << "Error creating socket." << std::endl;
        return;
    }

    sockaddr_in serverAddress{};
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(PORT);

    // Convert IP address to binary form
    if (inet_pton(AF_INET, "192.168.1.6", &(serverAddress.sin_addr)) <= 0) {
        std::cerr << "Invalid IP address." << std::endl;
        return;
    }

    // Connect to the server
    if (connect(clientSocket, (struct sockaddr*)&serverAddress, sizeof(serverAddress)) == -1) {
        std::cerr << "Error connecting to the server." << std::endl;
        return;
    }

    std::cout << "Connected to the server." << std::endl;
    socketConnected = true;
}

void closeConnection() {
    close(clientSocket);
    socketConnected = false;
}

void receiveFrame(QLabel& Cameralabel, char* buffer, bool& isRecording, cv::VideoWriter& writer) {
    // Receive frame size from the server
    int expectedSize = WIDTH * HEIGHT * 3;

    // Receive frame data from the server
    int bytesRead = 0;
    while (bytesRead < expectedSize) {
        int received = recv(clientSocket, buffer + bytesRead, expectedSize - bytesRead, 0);
        if (received <= 0) {
            std::cerr << "Error receiving frame data." << std::endl;
            closeConnection();
            break;
        }
        bytesRead += received;
    }

    // Convert received data to image
    cv::Mat receivedFrame = cv::Mat(HEIGHT, WIDTH, CV_8UC3, buffer);

    // Display the received frame
    cv::cvtColor(receivedFrame, receivedFrame, cv::COLOR_BGR2RGB);

    // Resize the received frame to fit within the label dimensions
    cv::Mat resizedFrame;
    cv::resize(receivedFrame, resizedFrame, cv::Size(320, 240));

    // Convert resized frame to QImage
    QImage qimage(resizedFrame.data, resizedFrame.cols, resizedFrame.rows, QImage::Format_RGB888);

    // Set the pixmap on the label
    Cameralabel.setPixmap(QPixmap::fromImage(qimage));

    cv::cvtColor(receivedFrame, receivedFrame, cv::COLOR_RGB2BGR);

    if (isRecording) {
        writer.write(receivedFrame);
    }
}


void captureImage(cv::Mat& frame, char* buffer, char index)
{
    frame = cv::Mat(HEIGHT, WIDTH, CV_8UC3, buffer);

    if (!frame.empty()) {
        // Generate a unique filename using timestamp
        QString currentDateTime = QDateTime::currentDateTime().toString("yyyy-MM-dd_hh-mm-ss");
        
        // Get the project's directory path
        QString projectDirPath = QDir::currentPath();
        
        // Set the temporary directory path within the project's directory
        QString tempDirPath = projectDirPath + QDir::separator() + "tmpimg";
        
        // Create the temporary directory if it doesn't exist
        QDir tempDir(tempDirPath);
        if (!tempDir.exists()) {
            tempDir.mkpath(".");
        }
        
        // Set the file path with the temporary directory
        QString filePath = tempDirPath + QDir::separator() + currentDateTime + index + ".jpg";
        
        // Save the image using OpenCV
        cv::imwrite(filePath.toStdString(), frame);
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void startRecording(bool& isRecording, cv::VideoWriter& writer) {
    if (!isRecording) {
        QString currentDateTime = QDateTime::currentDateTime().toString("yyyy-MM-dd_hh-mm-ss");
        QString projectDirPath = QDir::currentPath();
        QString tempDirPath = projectDirPath + QDir::separator() + "tmpvideo";
        
        // Create the temporary directory if it doesn't exist
        QDir tempDir(tempDirPath);
        if (!tempDir.exists()) {
            tempDir.mkpath(".");
        }
        QString filePath = tempDirPath + QDir::separator() + currentDateTime + "*.avi";
        if (!filePath.isEmpty()) {
            int codec = cv::VideoWriter::fourcc('M', 'J', 'P', 'G');
            double fps = 30.0; // Set a fixed frame rate (e.g., 30 fps)
            cv::Size frameSize(WIDTH, HEIGHT);
            writer.open(filePath.toStdString(), codec, fps, frameSize);

            if (writer.isOpened()) {
                isRecording = true;
            }
        }
    }
}

void stopRecording(bool& isRecording, cv::VideoWriter& writer) {
    if (isRecording) {
        isRecording = false;
        writer.release();
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

static int datasetCount = 1; // Static variable to keep track of dataset count

void newFolder(QWidget* parent)
{
    
    QString projectDirPath = QDir::currentPath();
    QString baseDirPath = projectDirPath + QDir::separator() + "datasets";

    // Construct the dataset folder name
    QString folderName = "dataset" + QString::number(datasetCount);
    QString folderPath = baseDirPath + QDir::separator() + folderName;
    
    // Create the dataset folder
    QDir folderDir(folderPath);
    folderDir.mkpath(".");
    QMessageBox::information(parent, "New Dataset", "New Dataset folder created successfully.");

    // Increment the dataset count for the next folder
    datasetCount++;
}

void deleteFolder(QWidget* parent)
{
    // Prompt the user to select the dataset folder
    QString selectedFolder = QFileDialog::getExistingDirectory(parent, "Select Dataset Folder", QDir::currentPath());

    if (!selectedFolder.isEmpty()) {
        // Confirm the deletion with the user
        QMessageBox::StandardButton reply;
        reply = QMessageBox::question(parent, "Confirm Deletion", "Are you sure you want to delete the selected dataset folder?", QMessageBox::Yes | QMessageBox::No);

        if (reply == QMessageBox::Yes) {
            // Delete the dataset folder
            QDir folderDir(selectedFolder);
            if (folderDir.exists()) {
                if (folderDir.removeRecursively()) {
                    QMessageBox::information(parent, "Deletion", "Dataset folder deleted successfully.");
                } else {
                    QMessageBox::critical(parent, "Error", "Failed to delete dataset folder.");
                }
            } else {
                QMessageBox::warning(parent, "Warning", "Dataset folder not found.");
            }
        }
    }
}

void mergeFolders(QWidget* parent)
{
    // Prompt the user to select the source and destination dataset folders
    QString sourceFolder = QFileDialog::getExistingDirectory(parent, "Select Source Dataset Folder", QDir::currentPath());
    QString destinationFolder = QFileDialog::getExistingDirectory(parent, "Select Destination Dataset Folder", QDir::currentPath());

    if (!sourceFolder.isEmpty() && !destinationFolder.isEmpty()) {
        // Confirm the merge operation with the user
        QMessageBox::StandardButton reply;
        reply = QMessageBox::question(parent, "Confirm Merge", "Are you sure you want to merge the datasets?", QMessageBox::Yes | QMessageBox::No);

        if (reply == QMessageBox::Yes) {
            // Iterate over the files in the source folder and move them to the destination folder
            QDir sourceDir(sourceFolder);
            QDir destinationDir(destinationFolder);
            QStringList files = sourceDir.entryList(QDir::Files);
            foreach (const QString& file, files) {
                QString sourceFilePath = sourceFolder + QDir::separator() + file;
                QString destinationFilePath = destinationFolder + QDir::separator() + file;
                QFile::rename(sourceFilePath, destinationFilePath);
            }

            // Remove the empty source folder
            if (sourceDir.removeRecursively()) {
                QMessageBox::information(parent, "Merge", "Dataset folders merged successfully.");
            } else {
                QMessageBox::critical(parent, "Error", "Failed to merge dataset folders.");
            }
        }
    }
}

void copyFolder(QWidget* parent)
{
    // Prompt the user to select the source and destination folders
    QString sourceFolder = QFileDialog::getExistingDirectory(parent, "Select Source Folder", QDir::currentPath());
    QString destinationFolder = QFileDialog::getExistingDirectory(parent, "Select Destination Folder", QDir::currentPath());

    if (!sourceFolder.isEmpty() && !destinationFolder.isEmpty()) {
        // Confirm the copy operation with the user
        QMessageBox::StandardButton reply;
        reply = QMessageBox::question(parent, "Confirm Copy", "Are you sure you want to copy the files?", QMessageBox::Yes | QMessageBox::No);

        if (reply == QMessageBox::Yes) {
            QDir sourceDir(sourceFolder);
            QDir destinationDir(destinationFolder);
            QStringList files = sourceDir.entryList(QDir::Files);

            foreach (const QString& file, files) {
                QString sourceFilePath = sourceFolder + QDir::separator() + file;
                QString destinationFilePath = destinationFolder + QDir::separator() + file;

                if (!QFile::copy(sourceFilePath, destinationFilePath)) {
                    QMessageBox::critical(parent, "Error", "Failed to copy file: " + sourceFilePath);
                    return;
                }
            }

            QMessageBox::information(parent, "Copy", "Files copied successfully.");
        }
    }
}

void processImages()
{
    // Prompt the user to select the folder
    QString folderPath = QFileDialog::getExistingDirectory(nullptr, "Select Folder", QDir::currentPath());

    if (!folderPath.isEmpty()) {
        QDir folderDir(folderPath);
        QStringList filters;
        filters << "*.jpg" << "*.jpeg" << "*.png"; // Add more image formats if needed
        folderDir.setNameFilters(filters);

        QStringList imageFiles = folderDir.entryList();
        foreach (const QString& imageFile, imageFiles) {
            QString imagePath = folderPath + QDir::separator() + imageFile;
            cv::Mat image = cv::imread(imagePath.toStdString());

            if (!image.empty()) {
                cv::Mat rotatedImage;
                cv::Mat flippedImage;

                // Apply rotation (90 degrees clockwise)
                cv::rotate(image, rotatedImage, cv::ROTATE_90_CLOCKWISE);

                // Apply flipping (horizontal flip)
                cv::flip(image, flippedImage, 1);

                // Extract the directory path from the image file path
                QString imageDirPath = QFileInfo(imagePath).dir().absolutePath();

                // Generate new filenames
                QString rotatedFileName = "rotated_" + imageFile;
                QString flippedFileName = "flipped_" + imageFile;

                // Construct the output file paths using the original directory path
                QString rotatedImagePath = imageDirPath + QDir::separator() + rotatedFileName;
                QString flippedImagePath = imageDirPath + QDir::separator() + flippedFileName;

                cv::imwrite(rotatedImagePath.toStdString(), rotatedImage);
                cv::imwrite(flippedImagePath.toStdString(), flippedImage);
            }
        }

        QMessageBox::information(nullptr, "Image Processing", "Image processing completed successfully.");
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void openVideo(QWidget* parent)
{
    // Prompt the user to select the video file
    QString videoFilePath = QFileDialog::getOpenFileName(parent, "Open Video", QDir::currentPath(), "Video Files (*.avi *.mp4)");

    if (!videoFilePath.isEmpty()) {
        // Create a VideoCapture object to read the video file
        cv::VideoCapture videoCapture(videoFilePath.toStdString());

        if (videoCapture.isOpened()) {
            cv::Mat frame;

            // Create a QLabel widget to display the video frames
            QLabel* videoLabel = new QLabel(parent);
            videoLabel->setGeometry(5, 190, 350, 300);
            videoLabel->show();

            // Read and display video frames until the end of the video
            while (videoCapture.read(frame)) {
                // Convert the OpenCV frame to a QImage for display
                QImage qImage(frame.data, frame.cols, frame.rows, frame.step, QImage::Format_RGB888);
                QPixmap pixmap = QPixmap::fromImage(qImage.rgbSwapped());

                // Scale the pixmap to fit the label dimensions
                pixmap = pixmap.scaled(videoLabel->size(), Qt::KeepAspectRatio);

                // Set the pixmap on the label
                videoLabel->setPixmap(pixmap);

                // Process events to update the label display
                QApplication::processEvents();
            }

            // Release the video capture object
            videoCapture.release();

            // Delete the video label widget
            delete videoLabel;
        }
        else {
            QMessageBox::critical(parent, "Error", "Failed to open video file.");
        }
    }
}


void openVideoWithInterval(QWidget* parent, int captureInterval)
{
    // Prompt the user to select the video file
    QString videoFilePath = QFileDialog::getOpenFileName(parent, "Open Video", QDir::currentPath(), "Video Files (*.avi *.mp4)");

    if (!videoFilePath.isEmpty()) {
        // Create a VideoCapture object to read the video file
        cv::VideoCapture videoCapture(videoFilePath.toStdString());

        if (videoCapture.isOpened()) {
            cv::Mat frame;
            bool isPlaying = true;
            // Create a QLabel widget to display the video frames
            QLabel* videoLabel = new QLabel(parent);
            videoLabel->setGeometry(5, 190, 350, 300);
            videoLabel->show();
            
            int frameRate = static_cast<int>(videoCapture.get(cv::CAP_PROP_FPS));
            int frameCount = 0;
            // Read and display video frames until the end of the video or playback is paused
            while (videoCapture.read(frame)) {
                if (isPlaying) {
                    // Convert the OpenCV frame to a QImage for display
                    QImage qImage(frame.data, frame.cols, frame.rows, frame.step, QImage::Format_RGB888);
                    QPixmap pixmap = QPixmap::fromImage(qImage.rgbSwapped());

                    // Scale the pixmap to fit the label dimensions
                    pixmap = pixmap.scaled(videoLabel->size(), Qt::KeepAspectRatio);

                    // Set the pixmap on the label
                    videoLabel->setPixmap(pixmap);

                    // Process events to update the label display and respond to user input
                    QApplication::processEvents();
                }

                // Capture frames every X seconds
                    frameCount++;

                    if (frameCount % (captureInterval * frameRate) == 0) {
                    // Capture the current frame
                    cv::Mat capturedFrame;
                    videoCapture >> capturedFrame;

                    // Save the captured frame to a file
                    if (!capturedFrame.empty()) {
                        QString currentDateTime = QDateTime::currentDateTime().toString("yyyy-MM-dd_hh-mm-ss");
                        QString projectDirPath = QDir::currentPath();
                        QString tempDirPath = projectDirPath + QDir::separator() + "tmpimg";
                        QDir tempDir(tempDirPath);
                        if (!tempDir.exists()) {
                            tempDir.mkpath(".");
                        }
                        QString fileName = tempDirPath + QDir::separator() + currentDateTime + ".jpg";
                        cv::imwrite(fileName.toStdString(), capturedFrame);
                        QMessageBox::information(parent, "Frame Captured", "Frame captured and saved successfully.");
                    } else {
                        QMessageBox::warning(parent, "Error", "Failed to capture frame.");
                    }
                }
            }

            videoCapture.release();
            delete videoLabel;

        } else {
            QMessageBox::warning(parent, "Error", "Failed to open video file.");
        }
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    QMainWindow window;
    window.setWindowTitle("Science box");
    window.resize(1090, 900);

    QLabel bgpicture(&window);
    QPixmap image("slika_iza.png");
    QSize originalSize = image.size();
    QPixmap scaledImage = image.scaled(originalSize * 1.5);
    bgpicture.setPixmap(scaledImage);
    bgpicture.setGeometry(150, 80, 750, 750);

    QPalette palette;
    palette.setColor(QPalette::Background, Qt::white);
    window.setPalette(palette);
    window.setAutoFillBackground(true);

    QLabel logo(&window);
    QPixmap imagelogo("logo1.png");
    logo.setPixmap(imagelogo);
    logo.setGeometry(570, 820, 500, 50);

    QLabel Camera1label(&window);
    Camera1label.setGeometry(5, 190, 350, 300);

    QLabel Camera2label(&window);
    Camera2label.setGeometry(360, 190, 350, 300);

    QLabel Camera3label(&window);
    Camera3label.setGeometry(715, 190, 350, 300);

    QLabel Camera4label(&window);
    Camera4label.setGeometry(5, 495, 350, 300);

    QLabel Camera5label(&window);
    Camera5label.setGeometry(360, 495, 350, 300);

    QLabel labeltext1("Camera 1 options", &window);
    labeltext1.setGeometry(5, 5, 150, 30);
    labeltext1.setAlignment(Qt::AlignCenter);
    labeltext1.setStyleSheet("background-color: #4169E1; color: white;");

    QLabel labeltext2("Camera 2 options", &window);
    labeltext2.setGeometry(160, 5, 150, 30);
    labeltext2.setAlignment(Qt::AlignCenter);
    labeltext2.setStyleSheet("background-color: #4169E1; color: white;");

    QLabel labeltext3("Camera 3 options", &window);
    labeltext3.setGeometry(315, 5, 150, 30);
    labeltext3.setAlignment(Qt::AlignCenter);
    labeltext3.setStyleSheet("background-color: #4169E1; color: white;");

    QLabel labeltext4("Camera 4 options", &window);
    labeltext4.setGeometry(470, 5, 150, 30);
    labeltext4.setAlignment(Qt::AlignCenter);
    labeltext4.setStyleSheet("background-color: #4169E1; color: white;");

    QLabel labeltext5("Camera 5 options", &window);
    labeltext5.setGeometry(625, 5, 150, 30);
    labeltext5.setAlignment(Qt::AlignCenter);
    labeltext5.setStyleSheet("background-color: #4169E1; color: white;");

    QLabel labeltext6("Dataset options", &window);
    labeltext6.setGeometry(780, 5, 150, 30);
    labeltext6.setAlignment(Qt::AlignCenter);
    labeltext6.setStyleSheet("background-color: #4169E1; color: white;");

    QLabel labeltext7("Video options", &window);
    labeltext7.setGeometry(935, 5, 150, 30);
    labeltext7.setAlignment(Qt::AlignCenter);
    labeltext7.setStyleSheet("background-color: #4169E1; color: white;");

    QPushButton Openbutton1("Open Camera", &window);
    Openbutton1.setGeometry(5, 35, 150, 30);

    QPushButton Openbutton2("Open Camera", &window);
    Openbutton2.setGeometry(160, 35, 150, 30);

    QPushButton Openbutton3("Open Camera", &window);
    Openbutton3.setGeometry(315, 35, 150, 30);

    QPushButton Openbutton4("Open Camera", &window);
    Openbutton4.setGeometry(470, 35, 150, 30);

    QPushButton Openbutton5("Open Camera", &window);
    Openbutton5.setGeometry(625, 35, 150, 30);

    QPushButton captureButton1("Capture picture", &window);
    captureButton1.setGeometry(5, 65, 150, 30);

    QPushButton captureButton2("Capture picture", &window);
    captureButton2.setGeometry(160, 65, 150, 30);

    QPushButton captureButton3("Capture picture", &window);
    captureButton3.setGeometry(315, 65, 150, 30);

    QPushButton captureButton4("Capture picture", &window);
    captureButton4.setGeometry(470, 65, 150, 30);

    QPushButton captureButton5("Capture picture", &window);
    captureButton5.setGeometry(625, 65, 150, 30);

    QPushButton startButton1("Start Recording", &window);
    startButton1.setGeometry(5, 95, 150, 30);

    QPushButton stopButton1("Stop Recording", &window);
    stopButton1.setGeometry(5, 125, 150, 30);

    QPushButton startButton2("Start Recording", &window);
    startButton2.setGeometry(160, 95, 150, 30);

    QPushButton stopButton2("Stop Recording", &window);
    stopButton2.setGeometry(160, 125, 150, 30);

    QPushButton startButton3("Start Recording", &window);
    startButton3.setGeometry(315, 95, 150, 30);

    QPushButton stopButton3("Stop Recording", &window);
    stopButton3.setGeometry(315, 125, 150, 30);

    QPushButton startButton4("Start Recording", &window);
    startButton4.setGeometry(470, 95, 150, 30);

    QPushButton stopButton4("Stop Recording", &window);
    stopButton4.setGeometry(470, 125, 150, 30);

    QPushButton startButton5("Start Recording", &window);
    startButton5.setGeometry(625, 95, 150, 30);

    QPushButton stopButton5("Stop Recording", &window);
    stopButton5.setGeometry(625, 125, 150, 30);

    QPushButton captureDurationButton1("Capture every X sec", &window);
    captureDurationButton1.setGeometry(5, 155, 150, 30);

    QPushButton captureDurationButton2("Capture every X sec", &window);
    captureDurationButton2.setGeometry(160, 155, 150, 30);

    QPushButton captureDurationButton3("Capture every X sec", &window);
    captureDurationButton3.setGeometry(315, 155, 150, 30);

    QPushButton captureDurationButton4("Capture every X sec", &window);
    captureDurationButton4.setGeometry(470, 155, 150, 30);

    QPushButton captureDurationButton5("Capture every X sec", &window);
    captureDurationButton5.setGeometry(625, 155, 150, 30);

    QPushButton openVideoButton("Chose Video", &window);
    openVideoButton.setGeometry(935, 35, 150, 30);

    QPushButton captureFramesButton("Capture frames", &window);
    captureFramesButton.setGeometry(935, 65, 150, 30);

    QPushButton createFolder("Create New Dataset", &window);
    createFolder.setGeometry(780, 35, 150, 30);

    QPushButton deleteFolderButton("Delete Dataset", &window);
    deleteFolderButton.setGeometry(780, 65, 150, 30);

    QPushButton copyFolderButton("Copy Dataset", &window);
    copyFolderButton.setGeometry(780, 95, 150, 30);

    QPushButton mergeButton("Merge Datasets", &window);
    mergeButton.setGeometry(780, 125, 150, 30);

    QPushButton processButton("Transform Dataset", &window);
    processButton.setGeometry(780, 155, 150, 30);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    QTimer timer;
    QObject::connect(&Openbutton1, &QPushButton::clicked, [&]() {
        if (!camera1On) {
            connectToServer();
            if (!socketConnected) {
                return;
            }
            camera1On = true;
            Openbutton1.setText("Close Camera");
            timer.start(30);
        } else {
            writer1.release();
            closeConnection();
            camera1On = false;
            Openbutton1.setText("Open Camera");
            timer.stop();
            Camera1label.clear();
        }
    });

    QObject::connect(&Openbutton2, &QPushButton::clicked, [&]() {
        if (!camera2On) {
            connectToServer();
            if (!socketConnected) {
                return;
            }
            camera2On = true;
            Openbutton2.setText("Close Camera");
            timer.start(30);
        } else {
            writer2.release();
            closeConnection();
            camera2On = false;
            Openbutton2.setText("Open Camera");
            timer.stop();
            Camera2label.clear();
        }
    });

    QObject::connect(&Openbutton3, &QPushButton::clicked, [&]() {
        if (!camera3On) {
            connectToServer();
            if (!socketConnected) {
                return;
            }
            camera3On = true;
            Openbutton3.setText("Close Camera");
            timer.start(30);
        } else {
            writer3.release();
            closeConnection();
            camera3On = false;
            Openbutton3.setText("Open Camera");
            timer.stop();
            Camera3label.clear();
        }
    });

    QObject::connect(&Openbutton4, &QPushButton::clicked, [&]() {
        if (!camera4On) {
            connectToServer();
            if (!socketConnected) {
                return;
            }
            camera4On = true;
            Openbutton4.setText("Close Camera");
            timer.start(30);
        } else {
            writer4.release();
            closeConnection();
            camera4On = false;
            Openbutton4.setText("Open Camera");
            timer.stop();
            Camera4label.clear();
        }
    });

    QObject::connect(&Openbutton5, &QPushButton::clicked, [&]() {
        if (!camera5On) {
            connectToServer();
            if (!socketConnected) {
                return;
            }
            camera5On = true;
            Openbutton5.setText("Close Camera");
            timer.start(30);
        } else {
            writer5.release();
            closeConnection();
            camera5On = false;
            Openbutton5.setText("Open Camera");
            timer.stop();
            Camera5label.clear();
        }
    });

    QObject::connect(&timer, &QTimer::timeout, [&]() {
        if (camera1On && socketConnected) {
            receiveFrame(Camera1label, buffer1, isRecording1, writer1);
        }
        if (camera2On && socketConnected) {
            receiveFrame(Camera2label, buffer2, isRecording2, writer2);
        }
        if (camera3On && socketConnected) {
            receiveFrame(Camera3label, buffer3, isRecording3, writer3);
        }
        if (camera4On && socketConnected) {
            receiveFrame(Camera4label, buffer4, isRecording4, writer4);
        }
        if (camera5On && socketConnected) {
            receiveFrame(Camera5label, buffer5, isRecording5, writer5);
        }
    });

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    QObject::connect(&captureButton1, &QPushButton::clicked, [&]() {captureImage(frame1, buffer1, index1);});
    QObject::connect(&captureButton2, &QPushButton::clicked, [&]() {captureImage(frame2, buffer2, index2);});
    QObject::connect(&captureButton3, &QPushButton::clicked, [&]() {captureImage(frame3, buffer3, index3);});
    QObject::connect(&captureButton4, &QPushButton::clicked, [&]() {captureImage(frame4, buffer4, index4);});
    QObject::connect(&captureButton5, &QPushButton::clicked, [&]() {captureImage(frame5, buffer5, index5);});

    QObject::connect(&startButton1, &QPushButton::clicked, [&]() {startRecording(isRecording1, writer1);});
    QObject::connect(&stopButton1, &QPushButton::clicked, [&]() {stopRecording(isRecording1, writer1);});

    QObject::connect(&startButton2, &QPushButton::clicked, [&]() {startRecording(isRecording2, writer2);});
    QObject::connect(&stopButton2, &QPushButton::clicked, [&]() {stopRecording(isRecording2, writer2);});

    QObject::connect(&startButton3, &QPushButton::clicked, [&]() {startRecording(isRecording3, writer3);});
    QObject::connect(&stopButton3, &QPushButton::clicked, [&]() {stopRecording(isRecording3, writer3);});

    QObject::connect(&startButton4, &QPushButton::clicked, [&]() {startRecording(isRecording4, writer4);});
    QObject::connect(&stopButton4, &QPushButton::clicked, [&]() {stopRecording(isRecording4, writer4);});

    QObject::connect(&startButton5, &QPushButton::clicked, [&]() {startRecording(isRecording5, writer5);});
    QObject::connect(&stopButton5, &QPushButton::clicked, [&]() {stopRecording(isRecording5, writer5);});

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    QObject::connect(&captureDurationButton1, &QPushButton::clicked, [&]() {
        if (captureDurationActive1) {
            captureDurationTimer1.stop();
            captureDurationActive1 = false;
            captureDurationButton1.setText("Capture every X sec");
        } else {
            // Prompt the user to enter the duration in seconds
            bool ok;
            int duration = QInputDialog::getInt(&window, "Capture Duration", "Enter duration in seconds:", 1, 1, 3600, 1, &ok);
            if (ok) {
                captureDurationTimer1.start(duration * 1000); // Convert seconds to milliseconds
                captureDurationActive1 = true;
                captureDurationButton1.setText("Stop capturing");
            }
        }
    });
    QObject::connect(&captureDurationTimer1, &QTimer::timeout, [&]() {captureImage(frame1, buffer1, index1);});

    QObject::connect(&captureDurationButton2, &QPushButton::clicked, [&]() {
        if (captureDurationActive2) {
            captureDurationTimer2.stop();
            captureDurationActive2 = false;
            captureDurationButton2.setText("Capture every X sec");
        } else {
            // Prompt the user to enter the duration in seconds
            bool ok;
            int duration = QInputDialog::getInt(&window, "Capture Duration", "Enter duration in seconds:", 1, 1, 3600, 1, &ok);
            if (ok) {
                captureDurationTimer2.start(duration * 1000); // Convert seconds to milliseconds
                captureDurationActive2 = true;
                captureDurationButton2.setText("Stop capturing");
            }
        }
    });
    QObject::connect(&captureDurationTimer2, &QTimer::timeout, [&]() {captureImage(frame2, buffer2, index2);});

    QObject::connect(&captureDurationButton3, &QPushButton::clicked, [&]() {
        if (captureDurationActive3) {
            captureDurationTimer3.stop();
            captureDurationActive3 = false;
            captureDurationButton3.setText("Capture every X sec");
        } else {
            // Prompt the user to enter the duration in seconds
            bool ok;
            int duration = QInputDialog::getInt(&window, "Capture Duration", "Enter duration in seconds:", 1, 1, 3600, 1, &ok);
            if (ok) {
                captureDurationTimer3.start(duration * 1000); // Convert seconds to milliseconds
                captureDurationActive3 = true;
                captureDurationButton3.setText("Stop capturing");
            }
        }
    });
    QObject::connect(&captureDurationTimer3, &QTimer::timeout, [&]() {captureImage(frame3, buffer3, index3);});

    QObject::connect(&captureDurationButton4, &QPushButton::clicked, [&]() {
        if (captureDurationActive4) {
            captureDurationTimer4.stop();
            captureDurationActive4 = false;
            captureDurationButton4.setText("Capture every X sec");
        } else {
            // Prompt the user to enter the duration in seconds
            bool ok;
            int duration = QInputDialog::getInt(&window, "Capture Duration", "Enter duration in seconds:", 1, 1, 3600, 1, &ok);
            if (ok) {
                captureDurationTimer4.start(duration * 1000); // Convert seconds to milliseconds
                captureDurationActive4 = true;
                captureDurationButton4.setText("Stop capturing");
            }
        }
    });
    QObject::connect(&captureDurationTimer4, &QTimer::timeout, [&]() {captureImage(frame4, buffer4, index4);});

    QObject::connect(&captureDurationButton5, &QPushButton::clicked, [&]() {
        if (captureDurationActive5) {
            captureDurationTimer5.stop();
            captureDurationActive5 = false;
            captureDurationButton5.setText("Capture every X sec");
        } else {
            // Prompt the user to enter the duration in seconds
            bool ok;
            int duration = QInputDialog::getInt(&window, "Capture Duration", "Enter duration in seconds:", 1, 1, 3600, 1, &ok);
            if (ok) {
                captureDurationTimer5.start(duration * 1000); // Convert seconds to milliseconds
                captureDurationActive5 = true;
                captureDurationButton5.setText("Stop capturing");
            }
        }
    });
    QObject::connect(&captureDurationTimer5, &QTimer::timeout, [&]() {captureImage(frame5, buffer5, index5);});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    QObject::connect(&openVideoButton, &QPushButton::clicked, [&]() {
        openVideo(&window);
    });

    QObject::connect(&captureFramesButton, &QPushButton::clicked, [&]() {
        bool ok;
        int captureInterval = QInputDialog::getInt(&window, "Capture Interval", "Enter the capture interval in seconds:", 1, 1, 9999, 1, &ok);
        if (ok) {
            openVideoWithInterval(&window, captureInterval);
        } else {
            QMessageBox::warning(&window, "Invalid Input", "Please enter a valid positive integer for the capture interval.");
        }
    });

    QObject::connect(&createFolder, &QPushButton::clicked, [&]() {newFolder(&window);});

    QObject::connect(&deleteFolderButton, &QPushButton::clicked, [&]() {
        deleteFolder(&window);
    });

    QObject::connect(&copyFolderButton, &QPushButton::clicked, [&]() {
        copyFolder(&window);
    });

    QObject::connect(&mergeButton, &QPushButton::clicked, [&]() {
        mergeFolders(&window);
    });

    QObject::connect(&processButton, &QPushButton::clicked, &processImages);

    window.show();

    return app.exec();
}
